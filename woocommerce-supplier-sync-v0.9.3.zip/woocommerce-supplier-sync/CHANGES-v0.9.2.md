# Changes in v0.9.2
- **Fixed: the "sync already running" lock could expire during a long run.**
  The lock lasts 25 minutes from the start of the run. A first run that reads
  the supplier file (~6 min) and then zeroes ~32,000 products (~18 min) can take
  about that long, which would have allowed a second sync (a manual click, or
  an automatic resume) to start on top of the first.
  The lock is now refreshed every 5,000 CSV rows, after every batch, and every
  1,000 products while zeroing. If the process dies, the refreshing stops and
  the lock still expires by itself, so an automatic resume is not blocked.

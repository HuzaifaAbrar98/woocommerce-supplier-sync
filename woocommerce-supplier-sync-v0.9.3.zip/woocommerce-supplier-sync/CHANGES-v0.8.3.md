# Changes in v0.8.3

- Added dashboard CSV upload for the main supplier file.
- Added dashboard CSV upload for the optional Skip-SKU file.
- Main upload is saved as `supplier-latest.csv`.
- Skip-SKU upload is saved as `supplier-skip-skus.csv`.
- Uploads are validated before replacing the existing local files.
- Dashboard shows presence, size, and modified time for both local files.
- Local processing now automatically uses `supplier-skip-skus.csv` when present, even if no FTP exclusion path is configured.
- FTP mode remains unchanged: it downloads the main file and, when configured, the Skip-SKU file from FTP.
- Existing local processing, resume/checkpoint, FTP/cURL handling, and exclusion logic are preserved.

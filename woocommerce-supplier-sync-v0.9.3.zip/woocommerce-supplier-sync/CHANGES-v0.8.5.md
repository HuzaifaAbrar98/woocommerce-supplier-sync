# Changes in v0.8.5

## Mixed FTP + Dashboard Skip-SKU mode

- Fixed the case where the main `supplier-latest.csv` is downloaded from FTP while `supplier-skip-skus.csv` was uploaded through the WordPress dashboard.
- In normal **Download & Run Sync** mode, a valid local `supplier-skip-skus.csv` now takes precedence over the optional FTP Skip-SKU path.
- The dashboard-uploaded exclusion file is loaded before processing the main supplier CSV, so matching SKUs are skipped before WooCommerce product loading/updating.
- A dashboard-uploaded Skip-SKU file is preserved after sync even when **Delete CSV After Sync** is enabled.
- If no usable local Skip-SKU file exists, the configured FTP Skip-SKU path remains the fallback.

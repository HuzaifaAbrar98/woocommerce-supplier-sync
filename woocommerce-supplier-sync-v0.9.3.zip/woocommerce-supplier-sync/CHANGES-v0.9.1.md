# Changes in v0.9.1
- Zero-out Safety Limit default raised from 70% to 85%.
  (If you already saved your settings, the saved value stays as it was: open
  Supplier Sync -> Settings -> Safety Limit (%) and type the new number.)

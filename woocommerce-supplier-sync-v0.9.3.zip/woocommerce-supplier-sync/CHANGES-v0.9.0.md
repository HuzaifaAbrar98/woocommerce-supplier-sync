# Changes in v0.9.0 - Zero out unmatched products

Built on top of your v0.8.6 (case-insensitive SKUs + Skip-SKU sheet).

## The rule
After the supplier file has been read to the very end, every website product
with a SKU is handled in this order of priority:

1. **In the Skip-SKU sheet** -> never touched (managed manually). This applies
   even when the SKU is not in the supplier file at all.
2. **In the supplier sheet** -> updated, or left unchanged if price and stock
   already match (exactly as before).
3. **In neither** -> regular price set to `0`, stock set to `0`, stock status
   "out of stock", backorders "no".

Products with no SKU are never touched. SKU matching stays case-insensitive.

## Settings (Supplier Sync -> Settings -> "Unmatched Products (Zero Out)")
| Setting | Default | Meaning |
|---|---|---|
| Zero Unmatched Products | **off** | Master switch. |
| Preview Only | **on** | Reports how many products WOULD be zeroed; changes nothing. |
| Safety Limit (%) | 85 | Zeroing is refused if it would hit more than this share of your products. |

## Safety guards (zeroing is skipped and the admin is emailed when...)
- not a single website product matched the supplier file (wrong/empty file);
- the share of products to be zeroed exceeds the Safety Limit (partial file);
- the record of matched products is missing, or the feature was switched on
  after the run had already started (so matches were not recorded);
- the sync did not reach the end of the supplier file (zeroing only ever runs
  after a complete pass).

## How it works / resume behaviour
- Matched product IDs are appended to `supplier-seen-ids.txt` (in the private
  plugin folder) after every 20,000-row batch, before the checkpoint is saved.
  The file is deleted when the run finishes.
- Zeroing runs in batches of 20,000 and appears in the dashboard Batches table
  as "(zeroing)" with a new "Zeroed (unmatched)" column.
- If the process dies during zeroing, the resume goes straight back to this
  phase; products already zeroed are skipped.
- Products already at price 0 / stock 0 / out of stock / no backorders are
  detected with ONE database query and are not loaded, so after the first real
  run only newly-unmatched products cost any time.
- The Last Sync table shows `zeroing_status` in plain English, and the result
  banner after each action includes it.

## Other fixes
- The batch counter no longer counts a trailing empty pass as an extra batch.
- `WSS_VERSION` constant now matches the plugin header.

## Things to know before enabling
- **Take a database backup first.** The plugin keeps no undo history.
- Price `0` (not blank) is what you asked for. WooCommerce would treat a
  price-0 product as free, which is why stock is forced to 0, out of stock and
  backorders off at the same time. Do not enable backorders on these products.
- If two website products ever share a SKU that differs only by letter case,
  they collapse to one key; the surplus one is never matched or zeroed.
- Tested with stubbed WordPress/WooCommerce (matched, unchanged, skipped,
  skipped-but-absent-from-supplier, invalid price, already-zero, preview,
  safety limit, wrong file, resume during zeroing, legacy checkpoint). Not yet
  run against a live WooCommerce store, which is why Preview Only is the default.

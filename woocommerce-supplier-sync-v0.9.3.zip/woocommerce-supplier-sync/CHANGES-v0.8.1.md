# Changes in v0.4.0

## Why you saw the same generic error after "updating"

The v0.3.0 zip extracted to a folder named `woocommerce-supplier-sync-v0.3.0`.
WordPress identifies a plugin by its folder name, so a new zip named
`woocommerce-supplier-sync-v0.4.0` installs as a **second, separate plugin**
rather than replacing the first. If the old one was still active, WordPress
kept running its (unpatched) code, which is why the message didn't change
even though the plugin code had.

**Fixed:** this build's folder is now just `woocommerce-supplier-sync` (no
version number), so future zips upgrade in place instead of duplicating.

### To install this version correctly
1. Go to Plugins in wp-admin.
2. Deactivate **and Delete** any existing "Supplier Sync" / "WooCommerce
   Supplier Sync" plugin entries (there may be two now — v0.2.0/v0.3.0 style
   folders).
3. Upload and activate this zip (`woocommerce-supplier-sync`).
4. Re-enter your FTP settings (deleting the old plugin also deletes its
   saved options).
5. Click **Test FTP Connection** again.

If your host uses PHP OPcache and the message is still stale after that,
ask them to restart PHP-FPM (or use the "Restart PHP" option in your hosting
control panel) to clear cached bytecode.

---

## Code changes, file by file

### `includes/class-wss-sync-engine.php`

**`test_connection()`**
- Added a raw `fsockopen( $host, $port )` check *before* touching the FTP
  extension at all. This tells you, independently of PHP's FTP functions,
  whether the server can open a TCP connection to the supplier at all.
  - If DNS won't resolve the hostname → returns `wss_dns_failed` with the
    exact hostname that failed.
  - If DNS resolves but the socket won't open → returns `wss_tcp_unreachable`
    with the host, port, and the raw socket errno/errstr, and explains that
    this is almost always a firewall/IP-allowlist issue on either side, and
    that FileZilla working locally does not rule this out (different
    machine, different IP, different firewall rule).
- Only if the TCP check passes does it proceed to the real FTP handshake via
  `connect()`.
- Wraps the handshake in `set_error_handler()` so PHP's suppressed `@ftp_*`
  warnings (e.g. "Connection refused", "SSL required", "Login incorrect")
  are captured and included in the returned error, instead of being thrown
  away.

**`connect()`**
- Added an explicit check for FTPS support: if "FTPS" is selected but this
  PHP build's FTP extension wasn't compiled with OpenSSL support (no
  `ftp_ssl_connect()`), returns a specific `wss_no_ftps_support` error rather
  than silently falling back to plain FTP.
- Handshake failures now report the host:port and any captured PHP warning,
  and note that this pattern (TCP connects, but the handshake fails) usually
  means the connection type (FTP vs FTPS) is wrong for what the supplier
  requires.
- Login failures now say plainly that the connection succeeded but the
  credentials were rejected, and remind you the password field always shows
  blank once saved, so a re-entry is needed to confirm it's correct.
- Passive mode (`ftp_pasv`) failures are no longer silently ignored — they're
  logged via `error_log()`, since a passive-mode failure is a common cause of
  "Test Connection" passing but the later file download hanging or failing.

**`download_file()`**
- Same warning-capture treatment as `test_connection()`, so a failed
  `ftp_get()` reports the real reason.
- The failure message now includes the exact remote path that was requested,
  and a reminder to double check it's not case-sensitive-wrong or sitting in
  a subdirectory of the FTP account root.

### `woocommerce-supplier-sync.php`
- Version bumped 0.3.0 → 0.4.0.

### No changes were made to:
- `class-wss-csv-processor.php` (CSV streaming/parsing/SKU rules — untouched)
- `class-wss-admin.php` (settings page, dashboard — untouched)
- `class-wss-plugin.php` (bootstrap — untouched)
- Scheduling logic, in-memory SKU lookup, changed-value-only update logic —
  all untouched, per the "do not rebuild" instruction.

---

## What the new error messages will tell you

Once this version is actually running (see install steps above), "Test FTP
Connection" will return one of these, each pointing at a different fix:

| Error code | Meaning | What to do |
|---|---|---|
| `wss_no_ftp_extension` | PHP's FTP module isn't enabled | Ask host to enable `ext-ftp` |
| `wss_dns_failed` | Hostname doesn't resolve from the server | Check for typos in the host field |
| `wss_tcp_unreachable` | Can't open a socket to host:port at all | Firewall/IP-allowlist issue — most likely given FileZilla works locally. Ask the supplier to allow-list your **server's** outbound IP (not your office IP), and ask your host if outbound port 21 is blocked |
| `wss_no_ftps_support` | FTPS selected, PHP build lacks SSL support | Switch to plain FTP, or ask host for an SSL-enabled FTP build |
| `wss_ftp_connect_failed` | TCP opened, but FTP handshake failed | Try switching FTP ↔ FTPS |
| `wss_ftp_login_failed` | Handshake OK, credentials rejected | Re-enter username/password in Settings |

---

# Changes in v0.4.1

## Root cause found: it was never DNS

The reported error was:
```
Could not resolve FTP hostname "ftp.stockinthechannel.co.uk/" from the web server.
```
Note the trailing `/`. The saved "FTP Host" setting had a slash on the end
(likely pasted in from a URL or an FTP client that includes it). PHP's
`gethostbyname()` and `fsockopen()` both treat `example.com/` as a literal,
invalid hostname — it's not that DNS was restricted, it's that a `/`
is not part of any valid hostname, so resolution fails every time,
regardless of firewall or DNS settings.

## Fix

**`includes/class-wss-admin.php`**
- Added `clean_host()`, run on every save of the Host field via
  `sanitize_settings()`. It:
  - trims whitespace
  - strips a leading scheme if pasted in (`ftp://`, `ftps://`, `http://`)
  - strips everything from the first `/` onward (path, trailing slash)
  - strips an accidentally-included `:port` suffix (since Port has its own
    field)
- This means pasting `ftp://ftp.example.co.uk/`, `ftp.example.co.uk/`, or
  `ftp.example.co.uk:21` into the Host field now all normalize to
  `ftp.example.co.uk` on save.

**`includes/class-wss-sync-engine.php`**
- Added the same cleanup (trim scheme/trailing path) directly in
  `test_connection()` and `connect()`, as a safety net for hosts that were
  already saved with bad data before this fix, so you don't strictly have to
  re-save the settings form for this specific case to be handled — though
  re-saving is still recommended for clarity.

## What to do now

Open Supplier Sync → Settings and re-check the Host field — it should show
just `ftp.stockinthechannel.co.uk` (no scheme, no trailing slash). Re-save
even though the safety net above should now handle it, then run "Test FTP
Connection" again. If it still fails, the new error message will tell you
the real next problem (this fix only removes the false "DNS" red herring —
if the supplier's firewall does also block your server's IP, you'll now see
`wss_tcp_unreachable` instead).

---

# Changes in v0.4.2

## Root cause

The "Local CSV Storage Path" field needs an absolute **server filesystem**
path (e.g. `/home/user/domains/example.co.uk/public_html/wp-content/uploads/wss/`),
but `/wp-content/uploads/2026` was entered — a **web URL path**, missing the
actual disk root, and also WordPress's public media library year/month
folder rather than a dedicated private folder for supplier data. PHP's
`mkdir()` can't create a directory from a path fragment like that, so
`wp_mkdir_p()` failed.

## Fix

**`includes/class-wss-admin.php`**
- `sanitize_settings()` now validates the saved Local CSV Storage Path: if
  it's empty, or doesn't start with `WP_CONTENT_DIR` (the real absolute path
  to this site's wp-content folder), it's replaced automatically with a safe
  computed default: `WP_CONTENT_DIR . '/uploads/wss-supplier-sync/'`. This
  makes the web-path-vs-filesystem-path mistake impossible to save.
- Updated the field's description to explain the difference and show the
  exact default path that will be used.

**`includes/class-wss-sync-engine.php`**
- `local_file_path()` error message now includes the exact directory it
  tried to create, so a future failure (e.g. permissions) is diagnosable
  without guessing.
- The storage folder now gets a `.htaccess` (`Require all denied`) and an
  empty `index.php` written into it automatically the first time it's
  created, since `wp-content/uploads` is normally public-facing and the CSV
  contains supplier pricing that shouldn't be reachable by URL.

## What to do now

Re-open Supplier Sync → Settings. You can now leave "Local CSV Storage Path"
blank and save — it will fill in the safe default itself. Then click "Run
Sync Now" again.

---

# Changes in v0.5.0 — Commercial hardening pass

## `includes/class-wss-sync-engine.php`
- **Concurrency lock**: `run()` now sets a transient lock (`wss_sync_running`, 25-minute self-expiring) at the start and releases it in a `finally` block. A second run (manual button pressed while the scheduled run is still going, or two overlapping scheduled runs) now returns `wss_already_running` and exits immediately instead of processing the same products twice.
- **Execution safeguards**: `set_time_limit(0)` and `ignore_user_abort(true)` added at the start of `run()`, since a 222MB file and tens of thousands of product saves can exceed default PHP execution limits when triggered over HTTP.
- **Failure email**: any failure (`WP_Error` from validation, download, or CSV processing) now emails the site's admin address via `wp_mail()`, so a broken run is noticed the same morning rather than silently sitting in the dashboard.
- **Optional CSV auto-delete**: if "Delete CSV After Sync" is checked (on by default), the downloaded file is deleted immediately after a successful sync.
- **Password decryption**: `connect()` now decrypts the stored FTP password via `WSS_Admin::decrypt_secret()` before logging in.
- Fixed `WSS_VERSION` constant, which was hardcoded to `0.3.0` in the main plugin file regardless of the actual release.

## `includes/class-wss-admin.php`
- **FTP password encryption at rest**: passwords are now encrypted with AES-256-CBC using a key derived from the site's own `AUTH_KEY`/`AUTH_SALT` before being saved to `wp_options`, instead of stored in plain text. A `wssenc:` prefix marks encrypted values; old plaintext values already saved are still read correctly (backward compatible) and get encrypted the next time the password is re-entered.
- Added a "Delete CSV After Sync" checkbox setting (defaults to checked for new installs).

## Still true / not changed
- No partial-corruption risk on failure: each product save is independent, so a mid-run failure leaves everything already processed correctly applied and nothing half-written.
- No automatic retry of a failed FTP download is implemented yet — a failed run today does not automatically try again later. Ask if you want this added (e.g. retry once after 30 minutes on failure).
- Bulk-write performance optimization (bypassing `WC_Product::save()` for speed) is **not** implemented — flagged as an optional, riskier future change, see the sync engine notes discussed separately, only worth doing if a real timed run shows it's needed.

## Recommended deployment for reliable 8:30 AM UK runs
Add a real server cron job in Hostinger hPanel (not just relying on WP-Cron):
```
30 8 * * * wp --path=/home/USERNAME/domains/YOURDOMAIN.co.uk/public_html cron event run wss_daily_sync_event
```
And add to `wp-config.php`:
```php
define( 'DISABLE_WP_CRON', true );
```

---

# Changes in v0.6.0 — Batch processing

## What changed and why

Batching doesn't reduce the total number of product saves — the same rows still get processed either way — but it gives you two things you asked for: **visibility into progress as it happens**, and **a real record of exactly how far a run got if it fails partway**, instead of an all-or-nothing result.

## `includes/class-wss-sync-engine.php`
- Added `const BATCH_SIZE = 20000` (CSV data rows per batch).
- `sync_csv()` rewritten: still opens the file once, still builds the SKU lookup map once (batching doesn't repeat that work), but now processes the file in chunks of 20,000 rows via a shared `process_row()` helper (extracted from the old inline loop, no logic changed — same skip rules, same changed-only-save rule).
- After **every** batch (not just at the end), results are written to two new options:
  - `wss_sync_batches` — an array of every completed batch's stats (rows read, updated, unchanged, unknown/blank SKU, invalid price/stock, errors, and how long that batch took).
  - `wss_sync_in_progress` — a live status marker (`running` / `complete`) with the running totals so far.
  
  Because these are saved after each batch rather than only at the very end, if a run is killed by a host timeout, an OOM, or a server reboot partway through, you keep an accurate record of every batch that did complete — nothing is silently lost, and you know exactly which batch it died on.

## `includes/class-wss-admin.php`
- Dashboard now shows a **Batches** table: one row per completed batch with its own counts and duration, filling in live as a sync progresses — refreshing the Supplier Sync dashboard page during a run shows new batches appear.
- Shows "A sync is currently running" while `wss_sync_in_progress` status is `running`.

## What this does *not* do (by design, for now)
- It does **not** speed up the run — same total product count, same `$product->save()` cost per changed item.
- It does **not** yet resume automatically from batch N if the whole process dies — the next scheduled run still starts from batch 1. True resume-from-checkpoint would mean persisting the file's byte offset and chaining separate WP-Cron events per batch instead of one long-running PHP process; happy to build that next if today's numbers show a full run doesn't reliably finish in one process.

---

# Changes in v0.7.2 — Resume-from-checkpoint + merged local-CSV testing mode

You had two different plugin lineages going at once: this one (up to v0.6.0, batching) and one ChatGPT built on top of that same v0.6.0 that added a "Process Existing Local CSV" button so you could test without a working FTP connection. This version merges both properly into one plugin, plus adds the true resume-from-failure feature you asked for.

## New: resume-from-checkpoint (`includes/class-wss-sync-engine.php`)

**The problem this solves:** previously, if a sync died partway through (host timeout, memory limit, power blip), the *next* run started over from row 1 — wasting the work already done and risking never finishing before 8:55 AM.

**How it works now:**
- After every 20,000-row batch, a checkpoint is saved: the exact byte position in the file (`ftell()`), which batch number it's on, the running totals, and the parsed CSV column positions.
- If a run is interrupted normally (an exception, a caught error), a `finally` block still cleans up as before.
- If a run is **hard-killed** by the host (a timeout or out-of-memory kill) — the case a `finally` block *cannot* catch, because the process just stops dead — a `register_shutdown_function()` callback (which PHP guarantees runs even after a fatal error) detects that the lock is still held and the last checkpoint says "incomplete." It then automatically schedules a resume attempt 3 minutes later via WP-Cron, and emails you saying so.
- The next run (whether that auto-scheduled resume, or the next day's normal 8:30 run, or you clicking a button) sees the incomplete checkpoint and **automatically resumes from that exact byte offset** instead of re-downloading and restarting — it seeks straight to where it left off and keeps going until the last SKU in the file is checked.
- The SKU lookup map is rebuilt fresh on resume (cheap, one query) in case anything changed on the site in between.
- Dashboard additions:
  - A warning banner when an incomplete sync is detected, with a **"Resume Incomplete Sync"** button to trigger it manually right away instead of waiting.
  - A **"Discard Incomplete Sync"** button, for the rare case the file itself was bad and you'd rather start clean.

## Merged: "Process Existing Local CSV" (from the ChatGPT-modified fork)

This is a genuinely useful feature and is now properly integrated rather than being a separate, diverging plugin:
- `run()` now takes two independent flags — `$resume` (checkpoint resume) and `$use_existing_local_csv` (skip FTP, use whatever file is already sitting at the configured Local CSV Storage Path). These are separate concerns and can't be confused with each other now.
- Dashboard has three clearly distinct actions: **Test FTP Connection**, **Download & Run Sync**, **Process Existing Local CSV**.
- Validates the local file exists, is readable, and isn't empty before processing, with a clear error message naming the exact expected path/filename if it's missing.

## Why your test run showed so many "Unknown SKU"

Looking at your batch results (105,711 unknown out of 126,730 rows read, only ~21,000 matched): this isn't necessarily a bug. It just means the manually-uploaded test CSV contains far more SKUs than exist in your 55,000-product store — the supplier's full catalog is larger than what you stock, which is completely normal for a distributor feed. Worth double-checking only if you expected a much higher match rate than ~21,000 — if so, compare a few "unknown" SKUs directly against a product's SKU field in WooCommerce to rule out formatting differences (extra spaces, leading zeros, different case).

## Still outstanding: the actual FTP connectivity problem

None of the above fixes *why* FTP still won't connect from the server — that's a separate, real infrastructure issue (see the `wss_tcp_unreachable` / `wss_dns_failed` / login-failure diagnostics from earlier versions). "Process Existing Local CSV" is a workaround for testing the sync logic, not a fix for automated daily sync, since it still requires you to manually place a file there. Once you're ready, send me whatever specific error "Test FTP Connection" now returns and I'll dig into that directly.

---

# Changes in v0.8.0 — Real fix for the "Type set to I" download failure + the "Forbidden" page

## Problem 1: "Forbidden — You don't have permission to access this resource."

Not a plugin bug. Your hosting security layer (WAF/ModSecurity) blocked the redirect *URL itself*, because the error message was placed directly in the query string and it contained `ftp_get():` — parentheses next to a function-looking name is a classic code-injection signature that firewalls scan for, so it blocked the whole page load before WordPress even ran.

**Fix (`includes/class-wss-admin.php`):** every action (Test Connection, Run Sync, Process Existing CSV, Resume, Discard) now stores its result message server-side in a short-lived transient (`set_flash_message()` / `get_flash_message()`) and redirects with a plain, clean URL — no message text in the query string at all. This is both safer (arguably you don't want internal error detail in a URL that could end up in browser history/logs) and avoids tripping the WAF again in the future, regardless of what the message says.

## Problem 2: "ftp_get(): Type set to I" — the real download failure

"Type set to I" is not an error — it's the FTP server's completely normal acknowledgement of binary transfer mode. The actual failure happens immediately after: your FTP server is behind NAT and answers the passive-mode request with its own **private/internal IP address** (something the public internet, including your web server, cannot route to). The login/control connection works fine (which is why "Test Connection" passed), but the second "data" connection PHP's native `ftp_get()` tries to open then fails silently against that unreachable private IP. This is a very common shared/VPS-hosting-to-shared-FTP-hosting problem, and PHP's built-in `ftp_*` functions have no setting to work around it.

**Fix (`includes/class-wss-sync-engine.php`):**
- The actual file transfer now uses **curl** (`download_via_curl()`) when available, with `CURLOPT_FTP_SKIP_PASV_IP => true` — this tells curl to ignore the bad IP the server proposes and reuse the address of the already-working control connection instead, which is the standard, correct fix for exactly this NAT scenario.
- If curl isn't available on the server, it falls back to the previous native `ftp_get()` method (`download_via_native_ftp()`), with a note in the error message suggesting curl be enabled.
- On a curl failure, the error message now includes curl's own error code/message, the FTP response code, and a trimmed verbose transfer log — much more diagnosable than a bare "could not connect."
- "Test FTP Connection" is unchanged (still native `ftp_*`, since that part was already working) — only the actual file transfer changed.

## What to do now
Just click **Download & Run Sync** again on this version — no settings changes needed. If curl is available on your server (it almost always is on Hostinger), this should resolve the download outright. If it still fails, the new error message will include curl's specific diagnostic rather than a generic failure.

---

# Changes in v0.8.1 — Fixed a fatal error I introduced, plus a real data-integrity guard

## Bug 1: fatal error on the dashboard ("critical error on this website")

This one's on me. In v0.8.0, when I added `set_flash_message()`/`get_flash_message()` to fix the WAF/"Forbidden" issue, my edit accidentally **deleted** the existing `batch_size_label()` function instead of adding alongside it. The dashboard calls `self::batch_size_label()` right in the "Batches" heading, so it fatally errored exactly there — matching what you saw (page cuts off right after "Batches (").

**Fixed:** `batch_size_label()` restored in `includes/class-wss-admin.php`.

## Bug 2 (real, not caused by me, but worth guarding against): "Existing SKUs Loaded: 0"

Your screenshot showed `Existing Skus Loaded: 0` while still reporting 3 updated / 2 unchanged — that combination shouldn't be possible with the matching logic as written (if the SKU map is truly empty, nothing can match), which suggests the number shown was stale data from an earlier attempt rather than from the run you just triggered. Rather than leave that ambiguous, `includes/class-wss-sync-engine.php` now:
- Explicitly checks for a real database error on the SKU-loading query and stops with a clear message if one occurred, instead of silently treating a DB error the same as "store has zero products."
- Refuses to proceed at all if it genuinely finds 0 existing SKUs in the database, since continuing would mark 100% of the CSV as "unknown" — a misleading result. It now stops with an explicit `wss_no_skus_found` error instead.

## What to do now
Reinstall this version and click "Download & Run Sync" again. You should see the Batches table render correctly this time, and "Existing SKUs Loaded" should show your real product count (should be in the tens of thousands) — if it doesn't, you'll now get a clear error explaining why instead of a silent zero.

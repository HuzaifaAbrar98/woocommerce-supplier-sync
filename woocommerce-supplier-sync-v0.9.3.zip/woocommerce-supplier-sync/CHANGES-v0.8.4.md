# Changes in v0.8.4

- Fixed the main supplier CSV price source to use the exact `Price` column.
- Removed `1stCheapestDistributorPrice` as a required/used price column.
- Stock continues to use `1stCheapestDistributorStock`.
- Updated dashboard validation text and documentation to require `SKU`, `Price`, and `1stCheapestDistributorStock`.

# Changes in v0.9.3
- **"Already zero" is now the literal rule you asked for.** A website product
  that reaches the zeroing step is left exactly as it is if its regular price
  is 0 AND its stock quantity is 0. Anything else is set to price 0 / stock 0.
  Previously the plugin also required "manage stock on", "out of stock" and
  "backorders off" before leaving a product alone.
  - A blank price is not treated as 0 (blank means "no price"), so those
    products are set to 0.
  - When a product IS changed, it is still saved with stock managed, status
    out of stock and backorders off, so a zeroed product cannot be bought.
  - Products already at price 0 / stock 0 are not loaded or saved at all, so
    the zeroing step also got a little faster (a lighter database query).
- Confirmed with a test: the supplier file can contain any number of SKUs that
  are not on the website (3,000 in the test). They are skipped as "unknown",
  nothing is created, and zeroing only ever looks at the website's own SKUs.
- Skip-sheet and supplier-sheet logic is unchanged.

## Known trade-off of the literal rule
A product with price 0 and stock quantity 0 that is still marked "in stock"
with stock management switched off is left alone, so it could still be
purchasable at price 0. If you ever see such products, tick "Manage stock" on
them or ask for the stricter check back.

# Changes in v0.8.2 — Optional Skip-SKU CSV

- Added an optional second FTP CSV containing SKUs that must never be updated.
- Added **Skip-SKU CSV Remote Path** in Supplier Sync settings. Leave blank to disable the feature.
- The second CSV is downloaded separately to `supplier-skip-skus.csv` in the same protected local directory as the main supplier CSV.
- The exclusion CSV must contain a `SKU` header.
- Excluded SKUs are checked before WooCommerce product lookup, so they cannot reach price/stock update logic.
- Added `excluded_sku` batch/total statistics to make skipped rows visible in the dashboard.
- Exclusion rules are stored in the checkpoint, so a resumed sync uses the same exclusion list as the original run.
- If **Delete CSV After Sync** is enabled, the exclusion CSV is deleted with the main supplier CSV.
- The existing **Process Existing Local CSV** action also supports the exclusion list by reading `supplier-skip-skus.csv` from the configured local directory.
- Fixed the plugin runtime version constant to match the release version (`0.8.2`).
